package com.example.demo.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "admin")
public class Admin {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "admin_id")
    private int adminId;

    @NotNull(message = "first name can not be empty")
    @Size(max = 20, message = "first name can't be more than 20 characters")
    @Size(min = 5, message = "first name must be more than 5 characters")
    @Column(name = "first_name")
    private String firstName;

    @NotNull(message = "last_name can not be empty")
    @Size(max = 20, message = "last_name can't be more than 20 characters")
    @Size(min = 4, message = "last_name must be more than 4 characters")
    @Column(name = "last_name")
    private String lastName;

    @Size(max = 20, message = "nameofadmin can't be more than 20 characters")
    @Size(min = 5, message = "nameofadmin must be more than 5 characters")
    @NotNull(message = "nameofadmin can not be empty")
    @Column(name = "nameofadmin",length=5)
    private String nameofadmin;

    @NotNull(message = "password can not be empty")
    @Size(min = 5, max = 20, message = "password must be between 5 to 20 characters long.")
    @Column(name = "password",length=6)
    private String pass_word;

    @Email(message = "Invalid email address")
    @Column(name = "email_id")
    private String emailId;

    @NotNull(message = "contact can not be empty")
    @Size(min = 10, max = 10, message = "contact must be 10  digits long.")
    @Column(name = "contact" ,length=10)
    private String contact;

    public Admin() {
    	
    }

   

	public Admin(int adminId,
			@NotNull(message = "first name can not be empty") @Size(max = 20, message = "first name can't be more than 20 characters") @Size(min = 5, message = "first name must be more than 5 characters") String firstName,
			@NotNull(message = "last_name can not be empty") @Size(max = 20, message = "last_name can't be more than 20 characters") @Size(min = 4, message = "last_name must be more than 4 characters") String lastName,
			@Size(max = 20, message = "nameofadmin can't be more than 20 characters") @Size(min = 5, message = "nameofadmin must be more than 5 characters") @NotNull(message = "nameofadmin can not be empty") String nameofadmin,
			@NotNull(message = "password can not be empty") @Size(min = 5, max = 20, message = "password must be between 5 to 20 characters long.") String pass_word,
			@Email(message = "Invalid email address") String emailId,
			@NotNull(message = "contact can not be empty") @Size(min = 10, max = 10, message = "contact must be 10  digits long.") String contact) {
		super();
		this.adminId = adminId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.nameofadmin = nameofadmin;
		this.pass_word = pass_word;
		this.emailId = emailId;
		this.contact = contact;
	}



	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNameofadmin() {
		return nameofadmin;
	}

	public void setNameofadmin(String nameofadmin) {
		this.nameofadmin = nameofadmin;
	}

	public String getPass_word() {
		return pass_word;
	}

	public void setPassword(String pass_word) {
		this.pass_word = pass_word;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
    

}