package com.example.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.BookingDao;
import com.example.demo.Dao.PaymentDao;
import com.example.demo.entity.Booking;
import com.example.demo.entity.Payment;
import com.example.demo.entity.User;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class PaymentServiceImpl implements PaymentService{
	@Autowired
	private PaymentDao paymentdao;
	
	@Autowired
	private BookingDao bookingdao;
	
	@Autowired
	private UserService userService;
	
	public PaymentServiceImpl(PaymentDao paymentdao,
			UserService userService) {
		super();
		this.paymentdao = paymentdao;
		
		this.userService = userService;
	}
	@Override
	public Payment addPayment(Payment payment, long bookingId, long userId) {
		//Booking booking = bookingdao.getById(bookingId);
		Booking booking = bookingdao.findById(bookingId).orElse(null);

		payment.setBookingId(bookingId);
		payment.setTotalPrice(booking.getTotalPrice());
		payment.setPaidDate(LocalDate.now());
		payment.setPaidAmount(booking.getTotalPrice());
		if (payment.getTotalPrice() == payment.getPaidAmount()) {
			booking.setStatus("Paid");
		} else {

			booking.setStatus("Not Paid");
		}
		User user = userService.findUserById(userId).orElse(null);
		payment.setUser(user);
    	return paymentdao.save(payment);
	}

	@Override
	public List<Payment> getAllPayments() {
		return paymentdao.findAll();
	}


	@Override
	public void deletePayment(long paymentId) {
		paymentdao.findById(paymentId);		
		if (paymentdao.existsById(paymentId)) {
		    paymentdao.deleteById(paymentId);
		}
	}


	@Override
	public Optional<Payment> findPaymentById(long id) {
		return this.paymentdao.findById(id);
	}
	@Override
	public List<Payment> getPaymentsByBookingId(long bookingId) {
		return paymentdao.findByBookingId(bookingId);
	}
	@Override
	public void deletePaymentsByBookingId(long bookingId) {
		paymentdao.findByBookingId(bookingId).forEach(payment -> paymentdao.delete(payment));
	}

	@Override
	public List<Payment> findPaymentsByUserId(long userId) {
		return paymentdao.findByUserUserId(userId);
	}

}
