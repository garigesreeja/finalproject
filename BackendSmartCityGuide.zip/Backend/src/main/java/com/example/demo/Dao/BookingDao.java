package com.example.demo.Dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Booking;

@Repository
public interface BookingDao extends JpaRepository<Booking, Long> {
	public List<Booking> findByBookingId(long bookingId);
	List<Booking> findByUserUserId(long userId);
}
