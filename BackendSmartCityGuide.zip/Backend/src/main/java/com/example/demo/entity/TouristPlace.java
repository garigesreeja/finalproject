package com.example.demo.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "TouristPlace")
public class TouristPlace {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "PlaceId")
    private int placeId;

    @NotNull(message = "Tourist Place name can not be empty")
    @Size(min = 3, message = "Tourist Place name can't be less than 3 characters")
    @Size(max = 50, message = "Tourist Place name can't be more than 50 characters")
    @Column(name = "PlaceName")
    private String placeName;

    @NotNull(message = "Location can not be empty")
    @Size(min = 4, message = "Location can't be less than 4 characters")
    @Size(max = 100, message = "Location can't be more than 50 characters")
    @Column(name = "Location")
    private String location;

    @NotBlank(message = "Timings can not be empty")
    @Column(name = "timings")
    private String timings;
    
    @Max(value = 3000, message = "Ticket price for children should not be more than 3000")
   @Min(value = 0, message = "Ticket price for children should not be less than 0")
    @Column(name = "TicketPriceChildren")
    private double ticketPriceChildren;
    @Max(value = 4000, message = "Ticket price for adults should not be more than 4000")
   @Min(value = 0, message = "Ticket price for adults should not be less than 0")
   
    @Column(name = "TicketPriceAdults")
    private double ticketPriceAdults;
   
    @Column(name = "Description")
    private String description;

    @NotBlank(message = "Contact can not be empty")
    @Size(max = 15, message = "Contact can't be more than 15 characters")
    @Size(min = 10, message = "Contact can't be less than 10 characters")
    @Column(name = "Contact")
    private String contact;

    @NotBlank(message = "Emailid can not be empty")
    @Email(message = "Invalid email format")
    @Size(max = 50, message = "Emailid can't be more than 50 characters")
    @Size(min = 10, message = "Emailid can't be less than 10 characters")
    @Column(name = "emailid")
    private String emailid;

   @Min(value = 1, message = "Rating should not be less than 1")
    @Max(value = 5, message = "Rating should not be greater than 5")
    @Column(name = "rating")
    private double rating;
   
    @NotBlank(message = "Image URL cannot be blank")
	@Column(name = "img")
	private String img;
    public TouristPlace() {

	}
    
public TouristPlace(int placeId, String placeName, String location, String timings, double ticketPriceChildren,
			double ticketPriceAdults, String description, String contact, String emailid, double rating, String img) {
		super();
		this.placeId = placeId;
		this.placeName = placeName;
		this.location = location;
		this.timings = timings;
		this.ticketPriceChildren = ticketPriceChildren;
		this.ticketPriceAdults = ticketPriceAdults;
		this.description = description;
		this.contact = contact;
		this.emailid = emailid;
		this.rating = rating;
		this.img = img;
	}

public int getPlaceId() {
	return placeId;
}

public void setPlaceId(int placeId) {
	this.placeId = placeId;
}

public String getPlaceName() {
	return placeName;
}

public void setPlaceName(String placeName) {
	this.placeName = placeName;
}

public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

public String getTimings() {
	return timings;
}

public void setTimings(String timings) {
	this.timings = timings;
}

public double getTicketPriceChildren() {
	return ticketPriceChildren;
}

public void setTicketPriceChildren(double ticketPriceChildren) {
	this.ticketPriceChildren = ticketPriceChildren;
}

public double getTicketPriceAdults() {
	return ticketPriceAdults;
}

public void setTicketPriceAdults(double ticketPriceAdults) {
	this.ticketPriceAdults = ticketPriceAdults;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getContact() {
	return contact;
}

public void setContact(String contact) {
	this.contact = contact;
}

public String getEmailid() {
	return emailid;
}

public void setEmailid(String emailid) {
	this.emailid = emailid;
}

public double getRating() {
	return rating;
}

public void setRating(double rating) {
	this.rating = rating;
}

public String getImg() {
	return img;
}

public void setImg(String img) {
	this.img = img;
}

@Override
public String toString() {
	return "TouristPlace [placeId=" + placeId + ", placeName=" + placeName + ", location=" + location + ", timings="
			+ timings + ", ticketPriceChildren=" + ticketPriceChildren + ", ticketPriceAdults=" + ticketPriceAdults
			+ ", description=" + description + ", contact=" + contact + ", emailid=" + emailid + ", rating=" + rating
			+ ", img=" + img + "]";
}


	


}