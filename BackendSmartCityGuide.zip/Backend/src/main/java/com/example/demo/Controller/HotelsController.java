package com.example.demo.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dao.HotelsDao;
import com.example.demo.entity.Hotels;
import com.example.demo.service.HotelsService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("Hotels")
public class HotelsController
{
	
	@Autowired
	HotelsService service;
	@Autowired
	HotelsDao Dao;
	private Hotels Hotels;
	
	@GetMapping("/list")
	public ResponseEntity<List<Hotels>>findAll()
	{
		return new ResponseEntity<List<Hotels>>(this.service.findAll(), HttpStatus.OK);
	}
	@GetMapping("/find/{hotelId}")
	public ResponseEntity<Hotels> getHotelsByhotelId(@PathVariable int hotelId)
	
    {
        System.out.println("Received a request to get Hotel by ID: " + hotelId);

        Optional<Hotels> hotel = service.findByhotelId(hotelId);

        if (hotel.isPresent()) {
            System.out.println("Returning Hotels: " + hotel.get());
            return new ResponseEntity<>(hotel.get(), HttpStatus.OK);
        } else {
            System.out.println("hotel not found for ID: " + hotelId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

	@PostMapping("/add")
    public ResponseEntity<Map<String,String>> saveProduct(@RequestBody Hotels H)
    {
        try
        {
            Optional<Hotels> existingproduct=this.Dao.findById(H.getHotelId());
            if(existingproduct.isEmpty())
            {
                
        
            this.service.savedata(H);
            Map<String,String> response=new HashMap<String,String>();
            response.put("status", "success");
            response.put("message", "Hotel added!!");
            return new ResponseEntity<Map<String,String>>(response, HttpStatus.CREATED);
            }
            else
            {
                Map<String,String> response=new HashMap<String,String>();
                response.put("status", "failed");
                response.put("message", "Hotel name already  found!!");
                return new ResponseEntity<Map<String,String>>(response, HttpStatus.NOT_FOUND);
            }
        }
        catch(Exception e1)
        {
            Map<String,String> response=new HashMap<String,String>();
            response.put("status", "failed");
            response.put("message", "Hotel not added!!");
            return new ResponseEntity<Map<String,String>>(response, HttpStatus.BAD_REQUEST);
        }
    }
	  @PutMapping("/update")
	    public ResponseEntity<Map<String, String>> updateHotels(@RequestBody Hotels H) {
	        try {
	            if (this.Dao.findById(H.getHotelId()).isPresent()) {
	                Hotels existingPlace = this.Dao.findById(H.getHotelId()).get();
	                existingPlace.setHotelName(H.getHotelName());
	                existingPlace.setLocation(H.getLocation());
	                existingPlace.setHotelPrice(H.getHotelPrice());
	                existingPlace.setNoOfRooms(H.getNoOfRooms());
	                existingPlace.setAbout(H.getAbout());
	                existingPlace.setRating(H.getRating());
	                existingPlace.setFacilities(H.getFacilities());
	                existingPlace.setImages(H.getImages());
	                

	                this.service.saveorUpdate(existingPlace);
	                Map<String, String> response = new HashMap<String, String>();
	                response.put("status", "success");
	                response.put("message", "Hotels data updated!!");
	                return new ResponseEntity<Map<String, String>>(response, HttpStatus.CREATED);
	            } else {
	                Map<String, String> response = new HashMap<String, String>();
	                response.put("status", "failed");
	                response.put("message", "Hotels data not found!!");
	                return new ResponseEntity<Map<String, String>>(response, HttpStatus.NOT_FOUND);
	            }
	        } catch (Exception e1) {
	            Map<String, String> response = new HashMap<String, String>();
	            response.put("status", "failed");
	            response.put("message", "Hotels not updated!!");
	            return new ResponseEntity<Map<String, String>>(response, HttpStatus.BAD_REQUEST);
	        }
	    }
	@DeleteMapping("/delete/{hotelId}")
	public ResponseEntity<Map<String,String>>deleteByhotelId(@PathVariable int hotelId)
	{
		try
		{
		    this.service.deleteByhotelId(hotelId);
			Map<String,String> response=new HashMap<String,String>();
			response.put("status", "success");
			response.put("message", "data deleted!!");
			return new ResponseEntity<Map<String,String>>(response, HttpStatus.OK);
		}
		catch(Exception e)
		{
			Map<String,String> response=new HashMap<String,String>();
			response.put("status", "failed");
			response.put("message", "data not deleted!!");
			return new ResponseEntity<Map<String,String>>(response, HttpStatus.NOT_FOUND);
		}		
	}
	@GetMapping("/search/{hotelName}")
	public ResponseEntity<?> getHotelsByhotelName(@RequestParam("hotelName") String hotelName)
	{
		//postTitle=postTitle.toLowerCase();
		if(this.service.getHotelsByhotelName(hotelName).isPresent())
		{
			return new ResponseEntity<Hotels>(this.service.getHotelsByhotelName(hotelName).get(),HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<String>("No Hotel found!",HttpStatus.NOT_FOUND);
		}
	}
	
}