package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Payment;
import com.example.demo.exception.PaymentNotFoundException;
import com.example.demo.service.PaymentService;

import java.util.List;
import java.util.Map;
import java.util.Optional;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("payments")
public class PaymentController {
    
    @Autowired
    private PaymentService paymentService;
    
    @PostMapping("{bookingId}/{userId}")
    public ResponseEntity<Payment> addPayment(@RequestBody Payment payment, @PathVariable long bookingId,
            @PathVariable long userId) {
        System.out.println("Received a request to add payment for booking ID: " + bookingId + " and user ID: " + userId);
        
        Payment addedPayment = paymentService.addPayment(payment, bookingId, userId);
        
        System.out.println("Payment added: " + addedPayment);
        return new ResponseEntity<>(addedPayment, HttpStatus.CREATED);
    }
    
    @GetMapping
    public List<Payment> getAllPayments() {
        System.out.println("Received a request to fetch all payments.");
        
        List<Payment> payments = paymentService.getAllPayments();
        System.out.println("Returning all payments: " + payments);

        return payments;
    }   
    
    @DeleteMapping("/delete/{paymentId}")
    public ResponseEntity<Map<String, String>> deletePayment(@PathVariable long paymentId) {
        System.out.println("Received a request to delete payment with ID: " + paymentId);
        
        paymentService.deletePayment(paymentId);
        System.out.println("Payment deleted for ID: " + paymentId);
        
        return new ResponseEntity<>(HttpStatus.OK);
    }
    
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Payment>> getPaymentsByUserId(@PathVariable long userId) {
        System.out.println("Received a request to fetch payments for customer ID: " + userId);
        
        List<Payment> payments = paymentService.findPaymentsByUserId(userId);
        if (payments.isEmpty()) {
            System.out.println("No payments found for user ID: " + userId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        
        System.out.println("Returning payments for user ID " + userId + ": " + payments);
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }
    
    @GetMapping("/{paymentId}")
    public ResponseEntity<Payment> findPaymentById(@PathVariable long paymentId) {
        System.out.println("Received a request to fetch payment by ID: " + paymentId);
        
        Optional<Payment> payment = paymentService.findPaymentById(paymentId);
        if (!payment.isPresent()) {
            System.out.println("Payment not found for ID: " + paymentId);
            throw new PaymentNotFoundException("Payment with ID " + paymentId + " not found.");
        }
        
        System.out.println("Returning payment for ID " + paymentId + ": " + payment.get());
        return new ResponseEntity<>(payment.get(), HttpStatus.OK);
    }
    
    @GetMapping("/bookingId/{bookingId}")
    public ResponseEntity<List<Payment>> getPaymentsByBookingId(@PathVariable long bookingId) {
        System.out.println("Received a request to fetch payments for booking ID: " + bookingId);
        
        List<Payment> payments = paymentService.getPaymentsByBookingId(bookingId);
        if (payments.isEmpty()) {
            System.out.println("No payments found for booking ID: " + bookingId);
            throw new PaymentNotFoundException("Payments with booking ID " + bookingId + " not found.");
        }
        
        System.out.println("Returning payments for booking ID " + bookingId + ": " + payments);
        return ResponseEntity.ok(payments);
    }

    @DeleteMapping("/deleteOrder/{bookingId}")
    public ResponseEntity<String> deletePaymentsByBookingId(@PathVariable long bookingId) {
        System.out.println("Received a request to delete payments for booking ID: " + bookingId);
        
        paymentService.deletePaymentsByBookingId(bookingId);
        System.out.println("Payments for Booking ID " + bookingId + " have been deleted.");
        
        return ResponseEntity.ok("Payments for Booking ID " + bookingId + " have been deleted.");
    }

}
