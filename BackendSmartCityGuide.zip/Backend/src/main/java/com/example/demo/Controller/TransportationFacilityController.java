package com.example.demo.Controller;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dao.TransportationFacilityDao;
import com.example.demo.entity.TransportationFacility;
import com.example.demo.service.TransportationFacilityService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("facilities")
public class TransportationFacilityController
{
	
	@Autowired
	TransportationFacilityService service;
	@Autowired
	TransportationFacilityDao Dao;
	private TransportationFacility TransportationFacility;
	
	@GetMapping("/list")
	public ResponseEntity<List<TransportationFacility>>findAll()
	{
		return new ResponseEntity<List<TransportationFacility>>(this.service.findAll(), HttpStatus.OK);
	}
	@GetMapping("/find/{id}")
	public ResponseEntity<?> getTransportationFacilityById(@PathVariable int id)
	{
		if((this.service).findById(id).isPresent())
		{
			return new ResponseEntity<TransportationFacility>(( this.service).findById(id).get(),HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<String>("TransportationFacility Id not found!",HttpStatus.NOT_FOUND);
		}
	}

	
	@PostMapping("/add")
    public ResponseEntity<Map<String,String>> saveTransportationFacility(@RequestBody TransportationFacility T)
    {
        try
        {
            Optional<TransportationFacility> existingplace=this.Dao.findById(T.getId());
            if(existingplace.isEmpty())
            {
            this.service.saveTransportation(T);
            Map<String,String> response=new HashMap<String,String>();
            response.put("status", "success");
            response.put("message", "Transportation Facility added!!");
            return new ResponseEntity<Map<String,String>>(response, HttpStatus.CREATED);
            }
            else
            {
                Map<String,String> response=new HashMap<String,String>();
                response.put("status", "failed");
                response.put("message", "Transportation Facility already  found!!");
                return new ResponseEntity<Map<String,String>>(response, HttpStatus.NOT_FOUND);
            }
        }
        catch(Exception e1)
        {
            Map<String,String> response=new HashMap<String,String>();
            response.put("status", "failed");
            response.put("message", "Transportation Facility not added!!");
            return new ResponseEntity<Map<String,String>>(response, HttpStatus.BAD_REQUEST);
        }
    }

	  @PutMapping("/update")
	    public ResponseEntity<Map<String, String>> updateTransportationFacility(@RequestBody TransportationFacility T) {
	        try {
	            if (this.Dao.findById(T.getId()).isPresent()) {
	            	TransportationFacility existingPlace = this.Dao.findById(T.getId()).get();
	            	existingPlace.setId(T.getId());
	                existingPlace.setTransportationType(T.getTransportationType());
	                existingPlace.setConvenience(T.getConvenience());
	                existingPlace.setMinCostPerRide(T.getMinCostPerRide());
	                existingPlace.setRating(T.getRating());
	                existingPlace.setImage(T.getImage());

	               

	                this.service.saveorUpdate(existingPlace);
	                Map<String, String> response = new HashMap<String, String>();
	                response.put("status", "success");
	                response.put("message", "TransportationFacility data updated!!");
	                return new ResponseEntity<Map<String, String>>(response, HttpStatus.CREATED);
	            } else {
	                Map<String, String> response = new HashMap<String, String>();
	                response.put("status", "failed");
	                response.put("message", "TransportationFacility data not found!!");
	                return new ResponseEntity<Map<String, String>>(response, HttpStatus.NOT_FOUND);
	            }
	        } catch (Exception e1) {
	            Map<String, String> response = new HashMap<String, String>();
	            response.put("status", "failed");
	            response.put("message", "TransportationFacility not updated!!");
	            return new ResponseEntity<Map<String, String>>(response, HttpStatus.BAD_REQUEST);
	        }
	    }
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Map<String,String>>deleteById(@PathVariable int id)
	{
		try
		{
		    this.service.deleteById(id);
			Map<String,String> response=new HashMap<String,String>();
			response.put("status", "success");
			response.put("message", "data deleted!!");
			return new ResponseEntity<Map<String,String>>(response, HttpStatus.OK);
		}
		catch(Exception e)
		{
			Map<String,String> response=new HashMap<String,String>();
			response.put("status", "failed");
			response.put("message", "data not deleted!!");
			return new ResponseEntity<Map<String,String>>(response, HttpStatus.NOT_FOUND);
		}		
	}
	@GetMapping("/search/{transportationType}")
	public ResponseEntity<?> getTransportationFacilityBytransportationType(@RequestParam("transportationType") String transportationType)
	{
		//postTitle=postTitle.toLowerCase();
		if(this.service.getTransportationFacilityBytransportationType(transportationType).isPresent())
		{
			return new ResponseEntity<TransportationFacility>(this.service.getTransportationFacilityBytransportationType(transportationType).get(),HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<String>("No TransportationFacility found!",HttpStatus.NOT_FOUND);
		}
	}
	
}