package com.example.demo.service;
import java.util.List;
import java.util.Optional;

import com.example.demo.entity.Hotels;
import com.example.demo.entity.TouristPlace;

public interface TouristService {
	public List<TouristPlace>findAll();
	public Optional<TouristPlace>findByPlaceId(int placeId);
	public void saveTouristPlace(TouristPlace T);
	public void saveorUpdate(TouristPlace T);
	public void deleteByPlaceId(int placeId);
	
	
	public Optional<TouristPlace> getTouristPlaceByPlaceName(String placeName);
}



