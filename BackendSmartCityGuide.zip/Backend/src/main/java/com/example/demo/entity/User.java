package com.example.demo.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.*;

@Entity
@Table(name = "users", uniqueConstraints = {@UniqueConstraint(columnNames = "user_name")})
public class User {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private long userId;

    @NotBlank(message = "User name cannot be blank")
    @Size(min = 2, max = 50, message = "User name must be between 2 and 50 characters")
    @Column(name = "users_name")
    private String usersName;

    @NotBlank(message = "User phone cannot be blank")
    @Pattern(regexp = "[0-9]+", message = "User phone must contain only digits")
    @Size(min = 10, max = 12, message = "User phone must be between 10 and 12 digits")
    @Column(name = "user_phone")
    private String userPhone;

    @NotBlank(message = "Username cannot be blank")
    @Size(min = 4, max = 20, message = "Username must be between 4 and 20 characters")
    @Column(name = "user_name")
    private String username;

    @NotBlank(message = "User password cannot be blank")
    @Size(min = 6, message = "User password must be at least 6 characters")
    @Column(name = "user_password")
    private String userpassword;

    @NotBlank(message = "Email cannot be blank")
    @Email(message = "Invalid email format")
    @Column(name = "email")
    private String email;

	public User() {
	}

	public User(long userId,
			@NotBlank(message = "User name cannot be blank") @Size(min = 2, max = 50, message = "User name must be between 2 and 50 characters") String usersName,
			@NotBlank(message = "User phone cannot be blank") @Pattern(regexp = "[0-9]+", message = "User phone must contain only digits") @Size(min = 10, max = 12, message = "User phone must be between 10 and 12 digits") String userPhone,
			@NotBlank(message = "Username cannot be blank") @Size(min = 4, max = 20, message = "Username must be between 4 and 20 characters") String username,
			@NotBlank(message = "User password cannot be blank") @Size(min = 6, message = "User password must be at least 6 characters") String userpassword,
			@NotBlank(message = "Email cannot be blank") @Email(message = "Invalid email format") String email) {
		super();
		this.userId = userId;
		this.usersName = usersName;
		this.userPhone = userPhone;
		this.username = username;
		this.userpassword = userpassword;
		this.email = email;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUsersName() {
		return usersName;
	}

	public void setUsersName(String usersName) {
		this.usersName = usersName;
	}

	public String getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", usersName=" + usersName + ", userPhone=" + userPhone + ", username="
				+ username + ", userpassword=" + userpassword + ", email=" + email + "]";
	}
}

