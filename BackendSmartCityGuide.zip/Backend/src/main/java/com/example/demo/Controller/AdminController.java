package com.example.demo.Controller;
import com.example.demo.entity.Admin;
import com.example.demo.entity.User;
import com.example.demo.Dao.AdminDao;
import com.example.demo.Dao.UserDao;
import com.example.demo.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:4200/")
public class AdminController {

    @Autowired
    AdminService service;
    @Autowired
	AdminDao dao;

    @GetMapping("/list")
    public ResponseEntity<List<Admin>> findAll() {
        System.out.println("Returning all Admin data:");
        return new ResponseEntity<>(this.service.findAll(), HttpStatus.OK);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<?> getAdminById(@PathVariable int id) {
        if (this.service.findById(id).isPresent()) {
            System.out.println("Returning Admin for ID: " + id);
            return new ResponseEntity<>(this.service.findById(id).get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Admin Id not found!", HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/addAdmin")
    public ResponseEntity<Map<String, String>> saveAdmin(@RequestBody Admin admin) {
        try {
            Optional<Admin> existingAdmin = this.service.findById(admin.getAdminId());

            if (existingAdmin.isEmpty()) {
                this.service.saveOrUpdate(admin);
                System.out.println("Admin data added successfully: " + admin);
                Map<String, String> response = new HashMap<>();
                response.put("status", "success");
                response.put("message", "Admin data added!!");
                return new ResponseEntity<>(response, HttpStatus.CREATED);
            } else {
                Map<String, String> response = new HashMap<>();
                response.put("status", "failed");
                response.put("message", "Admin already found!!");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e1) {
            Map<String, String> response = new HashMap<>();
            response.put("status", "failed");
            response.put("message", "Admin not added!!");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/update")
    public ResponseEntity<Map<String, String>> updateAdmin(@RequestBody Admin admin) {
        try {
            if (this.service.findById(admin.getAdminId()).isPresent()) {
                Admin existingAdmin = this.service.findById(admin.getAdminId()).get();
                existingAdmin.setFirstName(admin.getFirstName());
                existingAdmin.setLastName(admin.getLastName());
                existingAdmin.setNameofadmin(admin.getNameofadmin());
                existingAdmin.setPassword(admin.getPass_word());
                existingAdmin.setContact(admin.getContact());
                existingAdmin.setEmailId(admin.getEmailId());

                this.service.saveOrUpdate(existingAdmin);
                Map<String, String> response = new HashMap<>();
                response.put("status", "success");
                response.put("message", "Admin data updated!!");
                return new ResponseEntity<>(response, HttpStatus.CREATED);
            } else {
                Map<String, String> response = new HashMap<>();
                response.put("status", "failed");
                response.put("message", "Admin data not found!!");
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
            }
        } catch (Exception e1) {
            Map<String, String> response = new HashMap<>();
            response.put("status", "failed");
            response.put("message", "Admin not updated!!");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Map<String, String>> deleteAdminById(@PathVariable int id) {
        try {
            this.service.deleteById(id);
            System.out.println("Received a request to delete Admin data by ID: " + id);
            Map<String, String> response = new HashMap<>();
            response.put("status", "success");
            response.put("message", "Admin data deleted!!");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("status", "failed");
            response.put("message", "Admin data not deleted!!");
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        }
    }
    @GetMapping("/search")
	public ResponseEntity<?> getAdminByNameOfAdmin(@RequestParam("nameofadmin") String nameofadmin)
	{
		
		if(this.service.getAdminByNameOfAdmin(nameofadmin).isPresent())
		{
			return new ResponseEntity<Admin>(this.service.getAdminByNameOfAdmin(nameofadmin).get(),HttpStatus.OK);
		}
		else
		{
			return new ResponseEntity<String>("No Admin found!",HttpStatus.NOT_FOUND);
		}
	}
	@GetMapping("/search/{nameofadmin}")
    public ResponseEntity<List<Admin>> getAdminByAdminname(String nameofadmin)
    {
        //postTitle=postTitle.toLowerCase();
        return new ResponseEntity<List<Admin>>(this.service.findByAname(nameofadmin), HttpStatus.OK);
    }



    @PostMapping("/loginnew")
	public ResponseEntity<?> loginAdmin(@RequestBody Admin admindata) {
		Admin admin1 = dao.findBynameofadmin(admindata.getNameofadmin());

		if (admin1.getPass_word().equals(admindata.getPass_word())) {
			Admin sendadmin=new Admin();
			sendadmin.setAdminId(admin1.getAdminId());
			sendadmin.setFirstName(admin1.getFirstName());
			sendadmin.setLastName(admin1.getLastName());
			sendadmin.setNameofadmin(admin1.getNameofadmin());
			sendadmin.setPassword(admin1.getPass_word());
			sendadmin.setEmailId(admin1.getEmailId());
			sendadmin.setContact(admin1.getContact());
			
			return ResponseEntity.ok(sendadmin);
		} else {
			return (ResponseEntity<?>) ResponseEntity.internalServerError();
		}
	}
}

