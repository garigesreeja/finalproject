package com.example.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.BookingDao;
import com.example.demo.entity.Booking;
import com.example.demo.entity.Hotels;
import com.example.demo.entity.User;

import java.util.Date;
import java.util.List;

@Service
public class BookingServiceImpl implements BookingService {

	private final BookingDao bookingdao;

	@Autowired
	public BookingServiceImpl(BookingDao bookingdao) {
		this.bookingdao = bookingdao;
	}

	@Autowired
	UserService userservice;
	@Autowired
	HotelsService hotelservice;

	@Override
	public List<Booking> getAllBookings() {
		return bookingdao.findAll();
	}

	@Override
	public Booking getBookingById(Long bookingId) {
		return bookingdao.findById(bookingId).orElse(null);
	}

	@Override
	public void deleteBooking(Long bookingId) {
		bookingdao.deleteById(bookingId);

	}

	@Override
	public Booking saveBooking(Booking booking, long userId, int hotelId) {
		// Check if customer exists
		User user = userservice.findUserById(userId).orElse(null);
		if (user == null) {
			throw new IllegalArgumentException("Invalid User ID");
		}

		// Check if menu item exists
		Hotels hotel = hotelservice.findByhotelId(hotelId).orElse(null);
		if (hotel == null) {
			throw new IllegalArgumentException("Invalid Hotel ID");
		}

		booking.setBookingDate(new Date()); // Set the current date as the order date
		booking.setBookingTime(new Date()); // Set the current time as the order time
		// Calculate total price
		booking.calculateTotalPrice();
		// Set initial order status
		booking.setStatus("Not Paid");

		// Set customer and menu details
		booking.setUser(user);
		booking.setHotel(hotel);

		// Set total price in the entity to be saved in the database
		booking.setTotalPrice(booking.getTotalPrice());

		// Save the order
		return bookingdao.save(booking);
	}

	@Override
	public List<Booking> findBookingsByUserId(long userId) {
		return bookingdao.findByUserUserId(userId);
	}

	@Override
	public Booking getBookingById(int bookingId) {
		// TODO Auto-generated method stub
		return null;
	}

}