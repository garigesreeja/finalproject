package com.example.demo.Dao;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.example.demo.entity.TouristPlace;
import com.example.demo.entity.TransportationFacility;

@Repository
public interface TouristDao extends JpaRepository<TouristPlace, Integer> {

  //  static TouristPlace findTouristPlaceByPlaceName(String PlaceName) {
		// TODO Auto-generated method stub
	//	return null;
	//}

	//static List<TouristPlace> findByPnameIgnoreCase(String placeName) {
		// TODO Auto-generated method stub
	//	return null;
	//}
	 Optional<TouristPlace> findByPlaceId(int placeId);

	Optional<TouristPlace> getTouristPlaceByPlaceName(String placeName);
    
  
}