package com.example.demo.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
@Entity
@Table(name="TransportationFacilities")
public class TransportationFacility 
{
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	
    @Column(name = "id")
    private int id;

    @NotNull(message = "Transportation Facility Type can not be empty")
    @Size(max = 20, message = "Transportation Facility Type can't be more than 20 characters")
    @Size(min = 2, message = "Transportation Facility Type must be more than 2 characters")
    @Column(name = "TransportationType")
    private String transportationType;

    @NotNull(message = "Convenience can not be empty")
    @Size(max = 200, message = "Convenience can't be more than 200 characters")
    @Size(min = 0, message = "Convenience must be more than 0 characters")
    @Column(name = "Convenience")
    private String Convenience;

    @Size(max = 200, message = "MinCostPerRide can't be more than 20 characters")
    @Size(min = 0, message = "MinCostPerRide must be more than 0 characters")
    @NotNull(message = "MinCostPerRide can not be empty")
    @Column(name = "MinCostPerRide")
    private String MinCostPerRide;

    @NotNull(message = "Rating can not be empty")
    @Size(min = 0, max = 20, message = "Rating must be more than 0  characters long.")
    @Column(name = "Rating")
    private String Rating;

   
    @Column(name = "image")
    private String image;

    public TransportationFacility ()
    {
    	
    }

	public TransportationFacility(int id,
			@NotNull(message = "Transportation Facility Type can not be empty") @Size(max = 20, message = "Transportation Facility Type can't be more than 20 characters") @Size(min = 2, message = "Transportation Facility Type must be more than 2 characters") String transportationType,
			@NotNull(message = "Convenience can not be empty") @Size(max = 200, message = "Convenience can't be more than 200 characters") @Size(min = 0, message = "Convenience must be more than 0 characters") String convenience,
			@Size(max = 200, message = "MinCostPerRide can't be more than 200 characters") @Size(min = 0, message = "MinCostPerRide must be more than 0 characters") @NotNull(message = "MinCostPerRide can not be empty") String minCostPerRide,
			@NotNull(message = "Rating can not be empty") @Size(min = 0, max = 20, message = "Rating must be more than 0  characters long.") String rating,
			String image) {
		super();
		this.id = id;
		this.transportationType = transportationType;
		this.Convenience = convenience;
		this.MinCostPerRide = minCostPerRide;
		this.Rating = rating;
		this.image = image;
	}







	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTransportationType() {
		return transportationType;
	}

	public void setTransportationType(String transportationType) {
		this.transportationType = transportationType;
	}

	public String getConvenience() {
		return Convenience;
	}

	public void setConvenience(String convenience) {
		Convenience = convenience;
	}

	public String getMinCostPerRide() {
		return MinCostPerRide;
	}

	public void setMinCostPerRide(String minCostPerRide) {
		MinCostPerRide = minCostPerRide;
	}

	public String getRating() {
		return Rating;
	}

	public void setRating(String rating) {
		Rating = rating;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
}

