package com.example.demo.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.example.demo.entity.TransportationFacility;

public interface TransportationFacilityDao extends JpaRepository<TransportationFacility, Integer> {
    //List<> findByTransportationTypeIgnoreCase(String transportationType);
    Optional<TransportationFacility> findById(int id);
	//Optional<Hotels> deleteByhotelId(int hotelId);

	Optional<TransportationFacility> findBytransportationTypeIgnoreCase(String transportationType);

	
}

 