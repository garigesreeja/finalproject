package com.example.demo.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.AdminDao;
import com.example.demo.entity.Admin;

@Service
public class AdminServiceImpl implements AdminService {
	  @Autowired
    AdminDao adminDao;

   
    public AdminServiceImpl(AdminDao adminDao) {
        this.adminDao = adminDao;
    }

    @Override
    public List<Admin> findAll() {
        return adminDao.findAll();
    }

    @Override
    public Optional<Admin> findById(int id) {
        return adminDao.findById(id);
    }

    @Override
    public void saveOrUpdate(Admin admin) {
        adminDao.save(admin);
    }

    @Override
    public void deleteById(int id) {
        adminDao.deleteById(id);
    }


    @Override
    public List<Admin> findByAname(String nameofadmin) {
        return adminDao.findBynameofadminIgnoreCase(nameofadmin);
    }

	@Override
	public Admin findAdminByNameofadmin(String nameofadmin) {
		// TODO Auto-generated method stub
		return adminDao.findBynameofadmin( nameofadmin);
	}

	@Override
	public Optional<Admin> getAdminByNameOfAdmin(String nameofadmin) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	
}
