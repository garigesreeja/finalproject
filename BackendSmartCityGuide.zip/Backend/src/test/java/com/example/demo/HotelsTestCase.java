package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.Controller.HotelsController;
import com.example.demo.entity.Hotels;
import com.example.demo.service.HotelsService;

class HotelTestCases {

    @Mock
    private HotelsService hotelsService;

    @InjectMocks
    private HotelsController hotelsController;

    @Test
    void testFindAllHotels() {
        List<Hotels> hotelsList = new ArrayList<>();
        when(hotelsService.findAll()).thenReturn(hotelsList);

        ResponseEntity<List<Hotels>> response = hotelsController.findAll();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(hotelsList, response.getBody());
        verify(hotelsService, times(1)).findAll();
    }

    @Test
    void testGetHotelsByHotelId_HotelExists() {
        int hotelId = 1;
        Hotels hotel = new Hotels();
        when(hotelsService.findByhotelId(hotelId)).thenReturn(Optional.of(hotel));

        ResponseEntity<?> response = hotelsController.getHotelsByhotelId(hotelId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(hotel, response.getBody());
        verify(hotelsService, times(1)).findByhotelId(hotelId);
    }

    @Test
    void testGetHotelsByHotelId_HotelNotExists() {
        int hotelId = 1;
        when(hotelsService.findByhotelId(hotelId)).thenReturn(Optional.empty());

        ResponseEntity<?> response = hotelsController.getHotelsByhotelId(hotelId);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("hotel Id not found!", response.getBody());
        verify(hotelsService, times(1)).findByhotelId(hotelId);
    }

    @Test
    void testDeleteHotelById_Success() {
        int hotelId = 1;
        doNothing().when(hotelsService).deleteByhotelId(hotelId);

        ResponseEntity<Map<String, String>> response = hotelsController.deleteByhotelId(hotelId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("success", response.getBody().get("status"));
        assertEquals("data deleted!!", response.getBody().get("message"));
        verify(hotelsService, times(1)).deleteByhotelId(hotelId);
    }

    @Test
    void testDeleteHotelById_Failure() {
        int hotelId = 1;
        doThrow(new RuntimeException("Test exception")).when(hotelsService).deleteByhotelId(hotelId);

        ResponseEntity<Map<String, String>> response = hotelsController.deleteByhotelId(hotelId);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("failed", response.getBody().get("status"));
        assertEquals("data not deleted!!", response.getBody().get("message"));
        verify(hotelsService, times(1)).deleteByhotelId(hotelId);
    }

    
}
