package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.Controller.TransportationFacilityController;
import com.example.demo.entity.TransportationFacility;
import com.example.demo.service.TransportationFacilityService;

class TransportationFacilityTestCases {

    @Mock
    private TransportationFacilityService transportationFacilityService;

    @InjectMocks
    private TransportationFacilityController transportationFacilityController;

    @Test
    void testFindAllTransportationFacilities() {
        List<TransportationFacility> transportationFacilitiesList = new ArrayList<>();
        when(transportationFacilityService.findAll()).thenReturn(transportationFacilitiesList);

        ResponseEntity<List<TransportationFacility>> response = transportationFacilityController.findAll();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(transportationFacilitiesList, response.getBody());
        verify(transportationFacilityService, times(1)).findAll();
    }

    @Test
    void testGetTransportationFacilityById_TransportationFacilityExists() {
        int id = 1;
        TransportationFacility transportationFacility = new TransportationFacility();
        when(transportationFacilityService.findById(id)).thenReturn(Optional.of(transportationFacility));

        ResponseEntity<?> response = transportationFacilityController.getTransportationFacilityById(id);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(transportationFacility, response.getBody());
        verify(transportationFacilityService, times(1)).findById(id);
    }

    @Test
    void testGetTransportationFacilityById_TransportationFacilityNotExists() {
        int id = 1;
        when(transportationFacilityService.findById(id)).thenReturn(Optional.empty());

        ResponseEntity<?> response = transportationFacilityController.getTransportationFacilityById(id);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("TransportationFacility Id not found!", response.getBody());
        verify(transportationFacilityService, times(1)).findById(id);
    }

    @Test
    void testDeleteTransportationFacilityById_Success() {
        int id = 1;
        doNothing().when(transportationFacilityService).deleteById(id);

        ResponseEntity<Map<String, String>> response = transportationFacilityController.deleteById(id);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("success", response.getBody().get("status"));
        assertEquals("TransportationFacility data deleted!!", response.getBody().get("message"));
        verify(transportationFacilityService, times(1)).deleteById(id);
    }

    @Test
    void testDeleteTransportationFacilityById_Failure() {
        int id = 1;
        doThrow(new RuntimeException("Test exception")).when(transportationFacilityService).deleteById(id);

        ResponseEntity<Map<String, String>> response = transportationFacilityController.deleteById(id);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("failed", response.getBody().get("status"));
        assertEquals("TransportationFacility data not deleted!!", response.getBody().get("message"));
        verify(transportationFacilityService, times(1)).deleteById(id);
    }
}
