package com.example.demo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.Controller.EmailController;
import com.example.demo.service.EmailService;

class EmailControllerTests {

    @Mock
    private EmailService emailService;

    @InjectMocks
    private EmailController emailController;

    @Test
    void testCheckEmail_Success() {
        MockitoAnnotations.initMocks(this);

        // Mocking the email service to avoid actual email sending
        doNothing().when(emailService).sendEmail(anyString(), anyString(), anyString());

        ResponseEntity<String> response = emailController.checkEmail();

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Message Send", response.getBody());

        // Verify that the email service method is called with the expected parameters
        verify(emailService, times(1)).sendEmail("bhargavibhanu2409@gmail.com", "Check", "Hi Bhargavi You have successfully registered as admin");
    }
}

