package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.Controller.TouristController;
import com.example.demo.entity.TouristPlace;
import com.example.demo.service.TouristService;

class TouristControllerTest {

    @Mock
    private TouristService touristService;

    @InjectMocks
    private TouristController touristController;

    @Test
    void testFindAllTouristPlaces() {
        List<TouristPlace> touristPlacesList = new ArrayList<>();
        when(touristService.findAll()).thenReturn(touristPlacesList);

        ResponseEntity<List<TouristPlace>> response = touristController.findAll();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(touristPlacesList, response.getBody());
        verify(touristService, times(1)).findAll();
    }

    @Test
    void testGetTouristPlaceById_TouristPlaceExists() {
        int placeId = 1;
        TouristPlace touristPlace = new TouristPlace();
        when(touristService.findByPlaceId(placeId)).thenReturn(Optional.of(touristPlace));

        ResponseEntity<?> response = touristController.getTouristPlaceById(placeId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(touristPlace, response.getBody());
        verify(touristService, times(1)).findByPlaceId(placeId);
    }

    @Test
    void testGetTouristPlaceById_TouristPlaceNotExists() {
        int placeId = 1;
        when(touristService.findByPlaceId(placeId)).thenReturn(Optional.empty());

        ResponseEntity<?> response = touristController.getTouristPlaceById(placeId);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("TouristPlace Id not found!", response.getBody());
        verify(touristService, times(1)).findByPlaceId(placeId);
    }

    @Test
    void testDeleteTouristPlaceById_Success() {
        int placeId = 1;
        doNothing().when(touristService).deleteByPlaceId(placeId);

        ResponseEntity<Map<String, String>> response = touristController.deleteTouristPlaceById(placeId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("success", response.getBody().get("status"));
        assertEquals("TouristPlace data deleted!!", response.getBody().get("message"));
        verify(touristService, times(1)).deleteByPlaceId(placeId);
    }

    @Test
    void testDeleteTouristPlaceById_Failure() {
        int placeId = 1;
        doThrow(new RuntimeException("Test exception")).when(touristService).deleteByPlaceId(placeId);

        ResponseEntity<Map<String, String>> response = touristController.deleteTouristPlaceById(placeId);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("failed", response.getBody().get("status"));
        assertEquals("TouristPlace data not deleted!!", response.getBody().get("message"));
        verify(touristService, times(1)).deleteByPlaceId(placeId);
    }
}
