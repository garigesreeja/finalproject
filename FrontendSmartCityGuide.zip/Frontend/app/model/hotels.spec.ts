import { Hotels } from './hotels';

describe('Hotels', () => {
  it('should create an instance', () => {
    expect(new Hotels()).toBeTruthy();
  });
});
