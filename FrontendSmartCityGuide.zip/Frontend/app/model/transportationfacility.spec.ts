import { Transportationfacility } from './transportationfacility';

describe('Transportationfacility', () => {
  it('should create an instance', () => {
    expect(new Transportationfacility()).toBeTruthy();
  });
});
