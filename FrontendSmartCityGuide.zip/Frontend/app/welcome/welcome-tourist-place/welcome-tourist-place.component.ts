import { Component } from '@angular/core';

@Component({
  selector: 'app-welcome-tourist-place',
  templateUrl: './welcome-tourist-place.component.html',
  styleUrl: './welcome-tourist-place.component.css'
})
export class WelcomeTouristPlaceComponent {

}
