import { Component } from '@angular/core';

@Component({
  selector: 'app-transportwelcome',
  templateUrl: './transportwelcome.component.html',
  styleUrl: './transportwelcome.component.css'
})
export class TransportwelcomeComponent {

}
