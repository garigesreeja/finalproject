import { Component } from '@angular/core';

@Component({
  selector: 'app-touristwelcome',
  templateUrl: './touristwelcome.component.html',
  styleUrl: './touristwelcome.component.css'
})
export class TouristwelcomeComponent {

}
