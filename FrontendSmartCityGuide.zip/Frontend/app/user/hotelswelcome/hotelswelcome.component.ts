import { Component } from '@angular/core';

@Component({
  selector: 'app-hotelswelcome',
  templateUrl: './hotelswelcome.component.html',
  styleUrl: './hotelswelcome.component.css'
})
export class HotelswelcomeComponent {
 
}
